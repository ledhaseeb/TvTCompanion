# SafeWatch Mobile Companion App

Native Expo/React Native companion app for SafeWatch. Focused on session playback — launching video sessions, Chromecast/AirPlay casting with background support, and native video autoplay.

## Setup (Separate Expo Repl)

This app is designed to run in its own Expo Repl, pointing at the existing SafeWatch backend API. Chromecast, AirPlay, and Google Sign-In require a **dev client build** (not Expo Go).

### 1. Create a new Repl
- Use the **Expo** template on Replit
- Copy the contents of this `mobile/` directory into the new Repl's root

### 2. Install dependencies
```bash
npx expo install expo-router expo-constants expo-linking expo-status-bar expo-web-browser expo-av react-native-gesture-handler react-native-reanimated react-native-safe-area-context react-native-screens react-native-webview react-native-youtube-iframe @react-native-async-storage/async-storage @react-native-community/slider firebase @react-native-google-signin/google-signin react-native-google-cast
```

### 3. Configure environment variables
Set these in your Expo Repl's Secrets:
```
EXPO_PUBLIC_API_URL=https://your-safewatch-app.replit.app
EXPO_PUBLIC_FIREBASE_API_KEY=your-firebase-api-key
EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
EXPO_PUBLIC_FIREBASE_PROJECT_ID=your-firebase-project-id
EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID=your-google-web-client-id
```

### 4. Firebase & Google Sign-In Setup
- Place `GoogleService-Info.plist` (iOS) and `google-services.json` (Android) in the project root
- These files come from Firebase Console > Project Settings > Your apps
- The `webClientId` for Google Sign-In must match the Web client ID from Firebase Console

### 5. Build Dev Client (required for Cast + Google Sign-In)
```bash
npx expo prebuild
npx expo run:ios    # or run:android
```
Chromecast, AirPlay background audio, and Google Sign-In all require native modules that only work in a dev client build, not in Expo Go.

### 6. Run
```bash
npx expo start --dev-client --port 8081
```

## Architecture

- **Auth**: Firebase JS SDK for client-side authentication (email/password + Google Sign-In). After Firebase sign-in, the ID token is stored locally and sent as `Authorization: Bearer <token>` on all API requests. The backend verifies tokens with Firebase Admin SDK (same as web app). Automatic token refresh via `onIdTokenChanged` listener keeps sessions alive beyond the 1-hour ID token expiry.
- **Google Sign-In**: Uses `@react-native-google-signin/google-signin` for native Google OAuth, then exchanges the Google ID token for a Firebase credential via `signInWithCredential(GoogleAuthProvider.credential(googleIdToken))`. Requires dev client build.
- **API**: All data fetched from the existing Express backend via `EXPO_PUBLIC_API_URL`. Key endpoints:
  - `GET /api/users/me` — current user profile (or `POST /api/users/me` to create on first sign-up)
  - `GET /api/children` — list children
  - `POST /api/sessions/playlist` — server-side playlist generation
  - `POST /api/sessions` — create session (sends childIds, totalDurationSeconds, taperMode, flatlineLevel, includeWindDown, finishMode)
  - `PATCH /api/sessions/:id` — end session (`endedAt`, `totalDurationSeconds`)
  - `POST /api/watch-history` — record video watch (`videoId`, `childIds`, `sessionId`, `durationSeconds`, `stimulationLevel`)
  - `POST /api/feedback/:sessionId/complete` — submit behavior feedback (`skipped`, `behaviorRatings`, `participationPcts`)
- **Playlists**: Server-side generation via `POST /api/sessions/playlist`
- **Video**: `react-native-youtube-iframe` for native YouTube playback
- **Chromecast**: Integration via `react-native-google-cast` with a Custom Web Receiver. The CastContext discovers devices, manages sessions, and controls playback (load/pause/play/stop/seek). Videos are sent to the receiver using the YouTube video ID in `customData.videoId`; the Custom Web Receiver (`assets/cast/receiver.html`) loads the YouTube IFrame Player API to play them. This receiver must be hosted publicly and registered in the [Google Cast Developer Console](https://cast.google.com/publish/) to get a receiver app ID. Set `EXPO_PUBLIC_CAST_RECEIVER_APP_ID` to configure the app (defaults to the default media receiver for testing). Falls back gracefully when native module isn't available (Expo Go).
- **AirPlay**: Native iOS audio session configuration via `UIBackgroundModes: ["audio"]` in app.json. When combined with `react-native-youtube-iframe`'s WebView audio, AirPlay routing is handled by the system media controls.

## Screens

1. **Login** (`app/index.tsx`) - Email/password + Google Sign-In authentication
2. **Child Picker** (`app/(main)/children.tsx`) - Select children for session
3. **Session Config** (`app/(main)/session-config.tsx`) - Duration, energy pattern, finish mode
4. **Playlist Preview** (`app/(main)/playlist-preview.tsx`) - Preview with shuffle/replace/remove
5. **Player** (`app/(main)/player.tsx`) - Video playback with auto-advance, skip, cast, and stop

## Key Features

- Full autoplay support (bypasses WebKit restrictions)
- Auto-advance between videos with 5-second countdown
- Chromecast casting with automatic media loading on video changes
- AirPlay background audio support (iOS)
- Session feedback with per-child behavior ratings and participation slider
- Group session support (multiple children)
- Caregiver-restricted UI (session launch only, no management access)
- Session conflict detection (server returns error if child has active session)
- Watch history tracking per video with stimulation level
- Automatic Firebase token refresh (sessions survive beyond 1-hour expiry)

## Caregiver Experience

When a caregiver account signs in, the app automatically detects their role via `GET /api/users/me` (role: "caregiver"). The child picker shows children from the parent account (resolved server-side via `parentAccountId`). Caregivers can launch sessions but cannot access management features.

## Dev Client vs Expo Go

| Feature | Expo Go | Dev Client |
|---------|---------|------------|
| Email/Password login | Yes | Yes |
| Google Sign-In | No | Yes |
| Chromecast | No | Yes |
| AirPlay background | No | Yes |
| YouTube playback | Yes | Yes |
| Session management | Yes | Yes |
