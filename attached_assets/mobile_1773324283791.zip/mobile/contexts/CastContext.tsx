import { createContext, useContext, useState, useCallback, useEffect, ReactNode, ComponentType } from 'react';
import { ViewStyle } from 'react-native';

interface CastSession {
  device?: { friendlyName?: string };
}

interface CastStateEvent {
  castState: string;
}

interface CastMediaInfo {
  contentUrl: string;
  contentType: string;
  customData?: Record<string, unknown>;
  streamType?: string;
  metadata: { type: string; title: string };
}

interface CastClient {
  loadMedia?: (opts: { mediaInfo: CastMediaInfo; autoplay: boolean }) => Promise<void>;
  pause?: () => Promise<void>;
  play?: () => Promise<void>;
  stop?: () => Promise<void>;
  seek?: (opts: { position: number }) => Promise<void>;
}

interface CastEventSubscription {
  remove?: () => void;
}

interface GoogleCastModule {
  showIntroductoryOverlay?: () => void;
  showCastPicker?: () => Promise<void>;
  endSession?: (stopCasting: boolean) => Promise<void>;
  getClient?: () => CastClient | null;
  onCastStateChanged?: (cb: (state: CastStateEvent) => void) => CastEventSubscription;
  onSessionStarted?: (cb: (session: CastSession) => void) => CastEventSubscription;
  onSessionEnded?: (cb: () => void) => CastEventSubscription;
}

interface CastContextOptions {
  setOptions?: (opts: { receiverApplicationId: string }) => void;
}

let googleCastModule: GoogleCastModule | null = null;
let NativeCastButtonComponent: ComponentType<{ style?: ViewStyle; tintColor?: string }> | null = null;
let castContextInstance: CastContextOptions | null = null;

try {
  const mod = require('react-native-google-cast');
  googleCastModule = (mod.default || mod.GoogleCast) as GoogleCastModule;
  NativeCastButtonComponent = mod.CastButton;
  castContextInstance = mod.CastContext as CastContextOptions | null;
} catch {
}

const RECEIVER_APP_ID = process.env.EXPO_PUBLIC_CAST_RECEIVER_APP_ID;

interface CastContextType {
  isAvailable: boolean;
  isCasting: boolean;
  isConnecting: boolean;
  deviceName: string | null;
  castState: 'noDevicesAvailable' | 'notConnected' | 'connecting' | 'connected';
  requestSession: () => Promise<void>;
  endCastSession: () => Promise<void>;
  loadMedia: (youtubeVideoId: string, title?: string) => Promise<void>;
  pauseMedia: () => Promise<void>;
  playMedia: () => Promise<void>;
  stopMedia: () => Promise<void>;
  seekTo: (position: number) => Promise<void>;
  NativeCastButton: ComponentType<{ style?: ViewStyle; tintColor?: string }> | null;
}

const CastContext = createContext<CastContextType>({
  isAvailable: false,
  isCasting: false,
  isConnecting: false,
  deviceName: null,
  castState: 'noDevicesAvailable',
  requestSession: async () => {},
  endCastSession: async () => {},
  loadMedia: async () => {},
  pauseMedia: async () => {},
  playMedia: async () => {},
  stopMedia: async () => {},
  seekTo: async () => {},
  NativeCastButton: null,
});

export function CastProvider({ children }: { children: ReactNode }) {
  const [isAvailable, setIsAvailable] = useState(false);
  const [isCasting, setIsCasting] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [deviceName, setDeviceName] = useState<string | null>(null);
  const [castState, setCastState] = useState<CastContextType['castState']>('noDevicesAvailable');
  const [client, setClient] = useState<CastClient | null>(null);

  useEffect(() => {
    if (!googleCastModule) return;

    if (RECEIVER_APP_ID && castContextInstance?.setOptions) {
      castContextInstance.setOptions({ receiverApplicationId: RECEIVER_APP_ID });
    } else if (!RECEIVER_APP_ID) {
      console.warn('Chromecast: EXPO_PUBLIC_CAST_RECEIVER_APP_ID not set. YouTube casting requires a registered Custom Web Receiver. See mobile/README.md for setup.');
    }

    googleCastModule.showIntroductoryOverlay?.();

    const castStateListener = googleCastModule.onCastStateChanged?.((state: CastStateEvent) => {
      const stateMap: Record<string, CastContextType['castState']> = {
        noDevicesAvailable: 'noDevicesAvailable',
        notConnected: 'notConnected',
        connecting: 'connecting',
        connected: 'connected',
      };
      const mapped = stateMap[state?.castState] || 'noDevicesAvailable';
      setCastState(mapped);
      setIsAvailable(mapped !== 'noDevicesAvailable');
      setIsConnecting(mapped === 'connecting');
      setIsCasting(mapped === 'connected');
    });

    const sessionStarted = googleCastModule.onSessionStarted?.((session: CastSession) => {
      setIsCasting(true);
      setIsConnecting(false);
      setDeviceName(session?.device?.friendlyName || 'Cast Device');
      setClient(googleCastModule?.getClient?.() || null);
    });

    const sessionEnded = googleCastModule.onSessionEnded?.(() => {
      setIsCasting(false);
      setDeviceName(null);
      setClient(null);
    });

    return () => {
      castStateListener?.remove?.();
      sessionStarted?.remove?.();
      sessionEnded?.remove?.();
    };
  }, []);

  const requestSession = useCallback(async () => {
    if (!googleCastModule) {
      console.warn('Chromecast: react-native-google-cast not available. Requires dev client build.');
      return;
    }
    try {
      setIsConnecting(true);
      await googleCastModule.showCastPicker?.();
    } catch (err: unknown) {
      console.warn('Cast session request failed:', err instanceof Error ? err.message : err);
      setIsConnecting(false);
    }
  }, []);

  const endCastSession = useCallback(async () => {
    if (!googleCastModule) return;
    try {
      await googleCastModule.endSession?.(true);
    } catch {}
    setIsCasting(false);
    setDeviceName(null);
    setClient(null);
  }, []);

  const loadMedia = useCallback(async (youtubeVideoId: string, title?: string) => {
    if (!client && googleCastModule) {
      const c = googleCastModule.getClient?.() || null;
      if (c) setClient(c);
      else return;
    }
    const activeClient = client || googleCastModule?.getClient?.();
    if (!activeClient) return;

    try {
      await activeClient.loadMedia?.({
        mediaInfo: {
          contentUrl: youtubeVideoId,
          contentType: 'video/mp4',
          streamType: 'BUFFERED',
          customData: { videoId: youtubeVideoId },
          metadata: {
            type: 'generic',
            title: title || 'SafeWatch Video',
          },
        },
        autoplay: true,
      });
    } catch (err: unknown) {
      console.warn('Cast loadMedia failed:', err instanceof Error ? err.message : err);
    }
  }, [client]);

  const pauseMedia = useCallback(async () => {
    const activeClient = client || googleCastModule?.getClient?.();
    try {
      await activeClient?.pause?.();
    } catch {}
  }, [client]);

  const playMedia = useCallback(async () => {
    const activeClient = client || googleCastModule?.getClient?.();
    try {
      await activeClient?.play?.();
    } catch {}
  }, [client]);

  const stopMedia = useCallback(async () => {
    const activeClient = client || googleCastModule?.getClient?.();
    try {
      await activeClient?.stop?.();
    } catch {}
  }, [client]);

  const seekTo = useCallback(async (position: number) => {
    const activeClient = client || googleCastModule?.getClient?.();
    try {
      await activeClient?.seek?.({ position });
    } catch {}
  }, [client]);

  return (
    <CastContext.Provider
      value={{
        isAvailable,
        isCasting,
        isConnecting,
        deviceName,
        castState,
        requestSession,
        endCastSession,
        loadMedia,
        pauseMedia,
        playMedia,
        stopMedia,
        seekTo,
        NativeCastButton: NativeCastButtonComponent,
      }}
    >
      {children}
    </CastContext.Provider>
  );
}

export function useCast() {
  return useContext(CastContext);
}
