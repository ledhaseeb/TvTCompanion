import { useState, useCallback, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Dimensions } from 'react-native';
import YoutubePlayer, { YoutubeIframeRef } from 'react-native-youtube-iframe';
import { colors, spacing } from '@/lib/theme';

interface VideoPlayerProps {
  youtubeId: string;
  onEnd: () => void;
  onProgress?: (currentTime: number, duration: number) => void;
  autoPlay?: boolean;
}

const { width: screenWidth } = Dimensions.get('window');
const playerHeight = (screenWidth * 9) / 16;

export function VideoPlayer({
  youtubeId,
  onEnd,
  onProgress,
  autoPlay = true,
}: VideoPlayerProps) {
  const playerRef = useRef<YoutubeIframeRef>(null);
  const [isReady, setIsReady] = useState(false);
  const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  const handleStateChange = useCallback(
    (state: string) => {
      if (state === 'ended') {
        onEnd();
      }
    },
    [onEnd],
  );

  const handleReady = useCallback(() => {
    setIsReady(true);
  }, []);

  useEffect(() => {
    if (isReady && onProgress) {
      progressInterval.current = setInterval(async () => {
        try {
          const currentTime = await playerRef.current?.getCurrentTime();
          const duration = await playerRef.current?.getDuration();
          if (currentTime != null && duration != null) {
            onProgress(currentTime, duration);
          }
        } catch {}
      }, 1000);
    }

    return () => {
      if (progressInterval.current) {
        clearInterval(progressInterval.current);
      }
    };
  }, [isReady, onProgress]);

  return (
    <View style={styles.container}>
      <YoutubePlayer
        ref={playerRef}
        height={playerHeight}
        width={screenWidth}
        videoId={youtubeId}
        play={autoPlay}
        onChangeState={handleStateChange}
        onReady={handleReady}
        webViewProps={{
          allowsInlineMediaPlayback: true,
          mediaPlaybackRequiresUserAction: false,
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: screenWidth,
    height: playerHeight,
    backgroundColor: colors.black,
  },
});
