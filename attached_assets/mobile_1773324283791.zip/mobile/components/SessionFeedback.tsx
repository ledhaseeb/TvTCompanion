import { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import Slider from '@react-native-community/slider';
import { apiRequest } from '@/lib/query-client';
import { queryClient } from '@/lib/query-client';
import { colors, spacing, borderRadius } from '@/lib/theme';
import { BEHAVIOR_OPTIONS } from '@/lib/types';
import type { BehaviorRating } from '@/lib/types';

interface SessionFeedbackProps {
  visible: boolean;
  onDismiss: () => void;
  childIds: string[];
  childNames: string[];
  sessionId: string;
  totalMinutesWatched: number;
  wasOverride?: boolean;
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

const AVATAR_COLORS = ['#6366f1', '#ec4899', '#14b8a6', '#f97316', '#8b5cf6'];

export function SessionFeedback({
  visible,
  onDismiss,
  childIds,
  childNames,
  sessionId,
  totalMinutesWatched,
  wasOverride = false,
}: SessionFeedbackProps) {
  const [ratings, setRatings] = useState<Record<string, BehaviorRating>>({});
  const [participationPcts, setParticipationPcts] = useState<Record<string, number>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const isGroupSession = childIds.length > 1;
  const allRated = childIds.length > 0 && childIds.every(id => ratings[id]);

  const getPct = (id: string) => participationPcts[id] ?? 100;

  const handleSkip = async () => {
    try {
      await apiRequest('POST', `/api/feedback/${sessionId}/complete`, {
        skipped: true,
        behaviorRatings: [],
        participationPcts: {},
      });
    } catch {
    }
    onDismiss();
  };

  const handleSubmit = async () => {
    if (!allRated) return;
    setIsSubmitting(true);
    try {
      const ratingsArray = Object.entries(ratings).map(([childId, behaviorRating]) => ({
        childId,
        behaviorRating,
      }));
      await apiRequest('POST', `/api/feedback/${sessionId}/complete`, {
        skipped: false,
        behaviorRatings: ratingsArray,
        participationPcts: Object.fromEntries(childIds.map(id => [id, getPct(id)])),
      });
      childIds.forEach(id => {
        queryClient.invalidateQueries({ queryKey: ['/api/children', id, 'feedback'] });
      });
      queryClient.invalidateQueries({ queryKey: ['/api/feedback/pending'] });
      setShowSuccess(true);
      setSubmitError(null);
      setTimeout(() => {
        setShowSuccess(false);
        setRatings({});
        setParticipationPcts({});
        onDismiss();
      }, 1500);
    } catch (err: any) {
      setSubmitError(err.message || 'Failed to submit feedback. You can skip for now.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderChildFeedback = (childId: string, index: number) => {
    const name = childNames[index] || 'Unknown';
    const selected = ratings[childId];
    const pct = getPct(childId);
    const avatarColor = AVATAR_COLORS[index % AVATAR_COLORS.length];

    return (
      <View key={childId} style={styles.childSection}>
        {isGroupSession && (
          <View style={styles.childHeader}>
            <View style={[styles.avatar, { backgroundColor: avatarColor }]}>
              <Text style={styles.avatarText}>{getInitials(name)}</Text>
            </View>
            <Text style={styles.childName}>{name}</Text>
          </View>
        )}

        <View style={styles.ratingRow}>
          {BEHAVIOR_OPTIONS.map(option => (
            <TouchableOpacity
              key={option.value}
              style={[
                styles.ratingButton,
                selected === option.value && {
                  borderColor: option.color,
                  backgroundColor: option.color + '20',
                },
              ]}
              onPress={() => setRatings(prev => ({ ...prev, [childId]: option.value }))}
              disabled={isSubmitting}
              testID={`button-rating-${childId}-${option.value}`}
            >
              <Text style={styles.ratingLabel}>{option.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.participationSection}>
          <View style={styles.participationHeader}>
            <Text style={styles.participationLabel}>Participation</Text>
            <Text
              style={[
                styles.participationValue,
                pct < 100 && { color: colors.warning },
              ]}
            >
              {pct}%
            </Text>
          </View>
          <Slider
            style={styles.participationSlider}
            minimumValue={0}
            maximumValue={100}
            step={1}
            value={pct}
            onValueChange={v =>
              setParticipationPcts(prev => ({ ...prev, [childId]: v }))
            }
            minimumTrackTintColor={pct < 100 ? colors.warning : colors.primary}
            maximumTrackTintColor={colors.border}
            thumbTintColor={pct < 100 ? colors.warning : colors.primary}
            disabled={isSubmitting}
            testID={`slider-participation-${childId}`}
          />
          {pct < 100 && (
            <Text style={styles.walkedAwayText}>
              Walked away ~{Math.round((totalMinutesWatched * pct) / 100)}m in
            </Text>
          )}
        </View>
      </View>
    );
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={styles.modal}>
          {showSuccess ? (
            <View style={styles.successContainer}>
              <Text style={styles.successCheck}>✓</Text>
              <Text style={styles.successText}>Thanks for the feedback!</Text>
            </View>
          ) : (
            <>
              <Text style={styles.title}>
                {isGroupSession
                  ? 'How did everyone respond?'
                  : `How did ${childNames[0]} respond?`}
              </Text>
              <Text style={styles.subtitle}>
                {isGroupSession
                  ? "Rate each child's behavior after the session"
                  : 'Tap to rate, then adjust participation if they walked away early'}
              </Text>

              <ScrollView
                style={styles.scrollView}
                showsVerticalScrollIndicator={false}
              >
                {childIds.map((id, i) => renderChildFeedback(id, i))}
              </ScrollView>

              {submitError && (
                <Text style={styles.errorText}>{submitError}</Text>
              )}

              <View style={styles.buttonRow}>
                <TouchableOpacity
                  onPress={handleSkip}
                  style={styles.skipButton}
                  testID="button-skip-feedback"
                >
                  <Text style={styles.skipText}>Skip</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.doneButton,
                    (!allRated || isSubmitting) && styles.doneButtonDisabled,
                  ]}
                  onPress={handleSubmit}
                  disabled={!allRated || isSubmitting}
                  testID="button-submit-feedback"
                >
                  {isSubmitting ? (
                    <ActivityIndicator color={colors.white} />
                  ) : (
                    <Text style={styles.doneText}>Done</Text>
                  )}
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modal: {
    backgroundColor: colors.background,
    borderTopLeftRadius: borderRadius.xl,
    borderTopRightRadius: borderRadius.xl,
    padding: spacing.lg,
    maxHeight: '85%',
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    color: colors.text,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.xs,
    marginBottom: spacing.lg,
  },
  scrollView: {
    maxHeight: 400,
  },
  childSection: {
    marginBottom: spacing.lg,
  },
  childHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: '700',
  },
  childName: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  ratingRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  ratingButton: {
    flex: 1,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
  },
  ratingLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.text,
  },
  participationSection: {
    marginTop: spacing.md,
  },
  participationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  participationLabel: {
    fontSize: 13,
    color: colors.textSecondary,
  },
  participationValue: {
    fontSize: 13,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  participationSlider: {
    width: '100%',
    height: 30,
  },
  walkedAwayText: {
    fontSize: 12,
    color: colors.warning,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: spacing.lg,
    gap: spacing.md,
  },
  skipButton: {
    paddingVertical: 14,
    paddingHorizontal: spacing.lg,
  },
  skipText: {
    fontSize: 16,
    color: colors.textSecondary,
  },
  doneButton: {
    flex: 1,
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: 14,
    alignItems: 'center',
  },
  doneButtonDisabled: {
    opacity: 0.4,
  },
  doneText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  successContainer: {
    alignItems: 'center',
    paddingVertical: spacing.xxl,
  },
  successCheck: {
    fontSize: 48,
    color: colors.success,
  },
  successText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginTop: spacing.md,
  },
  errorText: {
    color: colors.error,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
});
