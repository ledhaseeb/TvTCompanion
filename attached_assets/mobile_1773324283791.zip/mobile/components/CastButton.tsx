import { TouchableOpacity, Text, View, StyleSheet, ActivityIndicator, ViewStyle, StyleProp } from 'react-native';
import { useCast } from '@/contexts/CastContext';
import { colors, spacing, borderRadius } from '@/lib/theme';

interface CastButtonProps {
  style?: StyleProp<ViewStyle>;
}

export function CastButton({ style }: CastButtonProps) {
  const {
    isAvailable,
    isCasting,
    isConnecting,
    deviceName,
    requestSession,
    endCastSession,
    NativeCastButton,
  } = useCast();

  if (NativeCastButton && isAvailable) {
    return (
      <View style={[styles.nativeWrapper, style]}>
        <NativeCastButton style={styles.nativeCastBtn} />
        {deviceName && (
          <Text style={styles.deviceLabel} numberOfLines={1}>
            {deviceName}
          </Text>
        )}
      </View>
    );
  }

  if (!isAvailable) return null;

  return (
    <TouchableOpacity
      style={[styles.button, isCasting && styles.buttonActive, style]}
      onPress={isCasting ? endCastSession : requestSession}
      disabled={isConnecting}
      testID="button-cast"
    >
      {isConnecting ? (
        <ActivityIndicator size="small" color={colors.white} />
      ) : (
        <Text style={styles.text}>
          {isCasting ? `${deviceName || 'TV'}` : 'Cast'}
        </Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  nativeWrapper: {
    alignItems: 'center',
    gap: 4,
  },
  nativeCastBtn: {
    width: 24,
    height: 24,
    tintColor: colors.white,
  },
  deviceLabel: {
    fontSize: 10,
    color: colors.textSecondary,
    maxWidth: 80,
  },
  button: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
    backgroundColor: '#1e293b',
  },
  buttonActive: {
    backgroundColor: colors.primary,
  },
  text: {
    color: colors.white,
    fontSize: 14,
    fontWeight: '500',
  },
});
