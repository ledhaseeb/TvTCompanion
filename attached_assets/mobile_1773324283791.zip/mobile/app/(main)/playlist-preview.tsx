import { useState, useCallback, useMemo, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { apiRequest } from '@/lib/query-client';
import { useSession } from '@/contexts/SessionContext';
import { colors, spacing, borderRadius } from '@/lib/theme';
import type { Video, TaperMode, PlaylistResponse } from '@/lib/types';

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function StimDots({ level }: { level: number }) {
  return (
    <View style={styles.stimDots}>
      {[1, 2, 3, 4, 5].map(i => (
        <View
          key={i}
          style={[
            styles.stimDot,
            {
              backgroundColor:
                i <= level
                  ? colors.stimulation[level] || colors.textTertiary
                  : colors.border,
            },
          ]}
        />
      ))}
    </View>
  );
}

export default function PlaylistPreviewScreen() {
  const params = useLocalSearchParams<{
    childIds: string;
    childNames: string;
    sessionMinutes: string;
    taperMode: string;
    flatlineLevel: string;
    includeWindDown: string;
    finishMode: string;
  }>();
  const router = useRouter();
  const { startSession } = useSession();

  const childIds = params.childIds?.split(',') ?? [];
  const childNames = params.childNames?.split(',') ?? [];
  const sessionMinutes = parseInt(params.sessionMinutes || '30', 10);
  const taperMode = (params.taperMode || 'taper_down') as TaperMode;
  const flatlineLevel = parseInt(params.flatlineLevel || '3', 10);
  const includeWindDown = params.includeWindDown === '1';
  const finishMode = (params.finishMode || 'soft') as 'soft' | 'hard';

  const [playlist, setPlaylist] = useState<Video[]>([]);
  const [calmingVideos, setCalmingVideos] = useState<Video[]>([]);
  const [replacementCandidates, setReplacementCandidates] = useState<Record<number, Video[]>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isShuffling, setIsShuffling] = useState(false);
  const [isReplacing, setIsReplacing] = useState<number | null>(null);
  const [isStarting, setIsStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchPlaylist = useCallback(async () => {
    try {
      const res = await apiRequest('POST', '/api/sessions/playlist', {
        childIds,
        sessionMinutes,
        taperMode,
        flatlineLevel,
      });
      const data: PlaylistResponse = await res.json();
      setPlaylist(data.playlist);
      setCalmingVideos(data.calmingVideos || []);
      setReplacementCandidates(data.replacementCandidates || {});
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to load playlist');
    } finally {
      setIsLoading(false);
    }
  }, [childIds, sessionMinutes, taperMode, flatlineLevel]);

  useEffect(() => {
    fetchPlaylist();
  }, [fetchPlaylist]);

  const totalDuration = useMemo(
    () => playlist.reduce((sum, v) => sum + v.durationSeconds, 0),
    [playlist],
  );

  const handleShuffle = async () => {
    setIsShuffling(true);
    try {
      const res = await apiRequest('POST', '/api/sessions/playlist', {
        childIds,
        sessionMinutes,
        taperMode,
        flatlineLevel,
      });
      const data: PlaylistResponse = await res.json();
      setPlaylist(data.playlist);
      if (data.calmingVideos?.length > 0) {
        setCalmingVideos(data.calmingVideos);
      }
      if (data.replacementCandidates) {
        setReplacementCandidates(data.replacementCandidates);
      }
    } catch {
      Alert.alert('Error', 'Failed to shuffle playlist');
    } finally {
      setIsShuffling(false);
    }
  };

  const handleReplace = async (index: number) => {
    setIsReplacing(index);
    try {
      const currentVideo = playlist[index];
      const maxStim = currentVideo.stimulationLevel;
      const playlistIds = new Set(playlist.map(v => v.id));

      for (let stim = maxStim; stim >= 0; stim--) {
        const pool = replacementCandidates[stim];
        if (!pool) continue;
        const available = pool.filter(v => !playlistIds.has(v.id));
        if (available.length > 0) {
          const pick = available[Math.floor(Math.random() * available.length)];
          const newPlaylist = [...playlist];
          newPlaylist[index] = pick;
          setPlaylist(newPlaylist);
          setReplacementCandidates(prev => ({
            ...prev,
            [stim]: prev[stim]?.filter(v => v.id !== pick.id) || [],
          }));
          return;
        }
      }

      const res = await apiRequest('POST', '/api/sessions/playlist/replace', {
        childIds,
        currentPlaylistVideoIds: playlist.map(v => v.id),
        replaceIndex: index,
        taperMode,
      });
      const data = await res.json();
      if (data.playlist) {
        setPlaylist(data.playlist);
      } else if (data.video) {
        const newPlaylist = [...playlist];
        newPlaylist[index] = data.video;
        setPlaylist(newPlaylist);
      }
    } catch {
      Alert.alert('Error', 'Failed to replace video');
    } finally {
      setIsReplacing(null);
    }
  };

  const handleRemove = (index: number) => {
    if (playlist.length <= 1) {
      Alert.alert('Cannot Remove', 'The playlist must have at least one video.');
      return;
    }
    setPlaylist(prev => prev.filter((_, i) => i !== index));
  };

  const handleStart = async () => {
    if (playlist.length === 0) return;
    setIsStarting(true);
    try {
      const sessionId = await startSession({
        childIds,
        childNames,
        playlist,
        calmingVideos,
        includeWindDown,
        taperMode,
        flatlineLevel,
        sessionMinutes,
        finishMode,
      });
      if (sessionId) {
        router.replace('/(main)/player');
      }
    } catch (err: any) {
      if (err.message?.includes('active session')) {
        Alert.alert(
          'Session Conflict',
          'One of the selected children already has an active session. Please end it first.',
        );
      } else {
        Alert.alert('Error', err.message || 'Failed to start session');
      }
    } finally {
      setIsStarting(false);
    }
  };

  const renderVideo = ({ item, index }: { item: Video; index: number }) => {
    const thumbnail = item.customThumbnailUrl || item.thumbnailUrl;
    return (
      <View style={styles.videoRow} testID={`video-item-${index}`}>
        <Text style={styles.videoIndex}>{index + 1}</Text>
        {thumbnail ? (
          <Image source={{ uri: thumbnail }} style={styles.thumbnail} />
        ) : (
          <View style={[styles.thumbnail, styles.thumbnailPlaceholder]}>
            <Text style={styles.thumbnailText}>No img</Text>
          </View>
        )}
        <View style={styles.videoInfo}>
          <Text style={styles.videoTitle} numberOfLines={2}>
            {item.title}
          </Text>
          <View style={styles.videoMeta}>
            <Text style={styles.videoDuration}>
              {formatDuration(item.durationSeconds)}
            </Text>
            <StimDots level={item.stimulationLevel} />
            {item.seriesName && (
              <Text style={styles.videoSeries} numberOfLines={1}>
                {item.seriesName}
              </Text>
            )}
          </View>
        </View>
        <View style={styles.videoActions}>
          <TouchableOpacity
            onPress={() => handleReplace(index)}
            style={styles.actionBtn}
            disabled={isReplacing === index}
            testID={`button-replace-${index}`}
          >
            {isReplacing === index ? (
              <ActivityIndicator size="small" color={colors.primary} />
            ) : (
              <Text style={styles.actionIcon}>↻</Text>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => handleRemove(index)}
            style={styles.actionBtn}
            testID={`button-remove-${index}`}
          >
            <Text style={[styles.actionIcon, { color: colors.error }]}>×</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Building playlist...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity style={styles.retryBtn} onPress={fetchPlaylist}>
            <Text style={styles.retryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} testID="button-back">
          <Text style={styles.backText}>Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Playlist Preview</Text>
        <TouchableOpacity
          onPress={handleShuffle}
          disabled={isShuffling}
          testID="button-shuffle"
        >
          {isShuffling ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Text style={styles.shuffleText}>Shuffle</Text>
          )}
        </TouchableOpacity>
      </View>

      <View style={styles.statsBar}>
        <View style={styles.stat}>
          <Text style={styles.statValue}>{playlist.length}</Text>
          <Text style={styles.statLabel}>Videos</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statValue}>
            {Math.ceil(totalDuration / 60)}m
          </Text>
          <Text style={styles.statLabel}>Duration</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statValue}>
            {new Date(Date.now() + totalDuration * 1000).toLocaleTimeString(
              [],
              { hour: 'numeric', minute: '2-digit' },
            )}
          </Text>
          <Text style={styles.statLabel}>Ends at</Text>
        </View>
      </View>

      <FlatList
        data={playlist}
        renderItem={renderVideo}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        contentContainerStyle={styles.listContent}
      />

      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.startBtn, isStarting && styles.startBtnDisabled]}
          onPress={handleStart}
          disabled={isStarting || playlist.length === 0}
          testID="button-start-playing"
        >
          {isStarting ? (
            <ActivityIndicator color={colors.white} />
          ) : (
            <Text style={styles.startBtnText}>Start Watching</Text>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing.md,
  },
  loadingText: {
    color: colors.textSecondary,
    fontSize: 16,
  },
  errorText: {
    color: colors.error,
    fontSize: 16,
    textAlign: 'center',
  },
  retryBtn: {
    marginTop: spacing.md,
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
  },
  retryText: {
    color: colors.white,
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '500',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  shuffleText: {
    color: colors.primary,
    fontSize: 15,
    fontWeight: '600',
  },
  statsBar: {
    flexDirection: 'row',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  stat: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  statLabel: {
    fontSize: 11,
    color: colors.textSecondary,
    marginTop: 1,
  },
  listContent: {
    paddingBottom: 100,
  },
  videoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    gap: spacing.sm,
  },
  videoIndex: {
    width: 24,
    fontSize: 14,
    color: colors.textTertiary,
    textAlign: 'center',
    fontWeight: '600',
  },
  thumbnail: {
    width: 80,
    height: 45,
    borderRadius: borderRadius.sm,
  },
  thumbnailPlaceholder: {
    backgroundColor: colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
  },
  thumbnailText: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  videoInfo: {
    flex: 1,
  },
  videoTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: colors.text,
    lineHeight: 18,
  },
  videoMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginTop: 3,
  },
  videoDuration: {
    fontSize: 12,
    color: colors.textSecondary,
  },
  videoSeries: {
    fontSize: 11,
    color: colors.textTertiary,
    maxWidth: 100,
  },
  stimDots: {
    flexDirection: 'row',
    gap: 2,
  },
  stimDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  videoActions: {
    flexDirection: 'row',
    gap: spacing.xs,
  },
  actionBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionIcon: {
    fontSize: 18,
    color: colors.primary,
    fontWeight: '600',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
    backgroundColor: colors.background,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  startBtn: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: 16,
    alignItems: 'center',
  },
  startBtnDisabled: {
    opacity: 0.5,
  },
  startBtnText: {
    color: colors.white,
    fontSize: 17,
    fontWeight: '600',
  },
});
