import { useState, useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '@/contexts/AuthContext';
import { colors, spacing, borderRadius } from '@/lib/theme';
import type { Child } from '@/lib/types';

function getAge(birthMonth: number, birthYear: number): number {
  const now = new Date();
  let age = now.getFullYear() - birthYear;
  if (now.getMonth() + 1 < birthMonth) age--;
  return Math.max(0, age);
}

function getInitials(name: string): string {
  return name
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export default function ChildrenScreen() {
  const { user, isCaregiver, logout } = useAuth();
  const router = useRouter();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const { data: children = [], isLoading, error } = useQuery<Child[]>({
    queryKey: ['/api/children'],
    enabled: !!user,
  });

  const toggleChild = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleStartSession = () => {
    if (selectedIds.size === 0) {
      Alert.alert('Select Children', 'Please select at least one child to start a session.');
      return;
    }
    const selectedChildren = children.filter(c => selectedIds.has(c.id));
    const params = {
      childIds: Array.from(selectedIds).join(','),
      childNames: selectedChildren.map(c => c.name).join(','),
    };
    router.push({
      pathname: '/(main)/session-config',
      params,
    });
  };

  const renderChild = ({ item, index }: { item: Child; index: number }) => {
    const age = getAge(item.birthMonth, item.birthYear);
    const isSelected = selectedIds.has(item.id);
    const avatarColor = colors.avatars[index % colors.avatars.length];

    return (
      <TouchableOpacity
        style={[styles.childCard, isSelected && styles.childCardSelected]}
        onPress={() => toggleChild(item.id)}
        activeOpacity={0.7}
        testID={`card-child-${item.id}`}
      >
        <View style={[styles.avatar, { backgroundColor: avatarColor }]}>
          <Text style={styles.avatarText}>{getInitials(item.name)}</Text>
        </View>
        <Text style={styles.childName}>{item.name}</Text>
        <Text style={styles.childAge}>
          {age} year{age !== 1 ? 's' : ''} old
        </Text>
        <Text style={styles.childTime}>{item.entertainmentMinutes}m daily limit</Text>
        {isSelected && (
          <View style={styles.checkmark}>
            <Text style={styles.checkmarkText}>✓</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color={colors.primary} style={styles.loader} />
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Failed to load children</Text>
          <Text style={styles.errorDetail}>{(error as Error).message}</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>
            {isCaregiver ? 'Caregiver Session' : 'SafeWatch'}
          </Text>
          <Text style={styles.headerSubtitle}>
            {children.length > 0
              ? 'Select children for this session'
              : 'No children configured yet'}
          </Text>
        </View>
        <TouchableOpacity onPress={logout} testID="button-logout">
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>

      {children.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyTitle}>No Children Found</Text>
          <Text style={styles.emptyText}>
            {isCaregiver
              ? 'The parent account has no children configured yet.'
              : 'Add children from the web dashboard to start using the app.'}
          </Text>
        </View>
      ) : (
        <>
          <FlatList
            data={children}
            renderItem={renderChild}
            keyExtractor={item => item.id}
            numColumns={2}
            columnWrapperStyle={styles.row}
            contentContainerStyle={styles.listContent}
          />
          <View style={styles.footer}>
            <TouchableOpacity
              style={[
                styles.startButton,
                selectedIds.size === 0 && styles.startButtonDisabled,
              ]}
              onPress={handleStartSession}
              disabled={selectedIds.size === 0}
              testID="button-start-session"
            >
              <Text style={styles.startButtonText}>
                {selectedIds.size > 1
                  ? `Start Group Session (${selectedIds.size})`
                  : selectedIds.size === 1
                  ? 'Configure Session'
                  : 'Select Children'}
              </Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.text,
  },
  headerSubtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: 2,
  },
  logoutText: {
    color: colors.primary,
    fontSize: 14,
    fontWeight: '500',
  },
  loader: {
    flex: 1,
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  errorText: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.error,
  },
  errorDetail: {
    fontSize: 14,
    color: colors.textSecondary,
    marginTop: spacing.sm,
    textAlign: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xxl,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: colors.text,
  },
  emptyText: {
    fontSize: 15,
    color: colors.textSecondary,
    textAlign: 'center',
    marginTop: spacing.sm,
    lineHeight: 22,
  },
  listContent: {
    padding: spacing.md,
    paddingBottom: 100,
  },
  row: {
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  childCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  childCardSelected: {
    borderColor: colors.primary,
    backgroundColor: '#e8f0fe',
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  avatarText: {
    color: colors.white,
    fontSize: 22,
    fontWeight: '700',
  },
  childName: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  childAge: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 2,
  },
  childTime: {
    fontSize: 12,
    color: colors.textTertiary,
    marginTop: 2,
  },
  checkmark: {
    position: 'absolute',
    top: spacing.sm,
    right: spacing.sm,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkmarkText: {
    color: colors.white,
    fontSize: 14,
    fontWeight: '700',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
    backgroundColor: colors.background,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  startButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: 16,
    alignItems: 'center',
  },
  startButtonDisabled: {
    opacity: 0.4,
  },
  startButtonText: {
    color: colors.white,
    fontSize: 17,
    fontWeight: '600',
  },
});
