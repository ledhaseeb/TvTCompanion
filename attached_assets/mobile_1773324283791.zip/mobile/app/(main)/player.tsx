import { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { VideoPlayer } from '@/components/VideoPlayer';
import { CastButton } from '@/components/CastButton';
import { SessionFeedback } from '@/components/SessionFeedback';
import { useSession } from '@/contexts/SessionContext';
import { useCast } from '@/contexts/CastContext';
import { apiRequest } from '@/lib/query-client';
import { colors, spacing, borderRadius } from '@/lib/theme';

const COUNTDOWN_SECONDS = 5;

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function StimDots({ level }: { level: number }) {
  return (
    <View style={styles.stimDots}>
      {[1, 2, 3, 4, 5].map(i => (
        <View
          key={i}
          style={[
            styles.stimDot,
            {
              backgroundColor:
                i <= level
                  ? colors.stimulation[level] || colors.textTertiary
                  : colors.border,
            },
          ]}
        />
      ))}
    </View>
  );
}

export default function PlayerScreen() {
  const router = useRouter();
  const {
    session,
    advanceVideo,
    endSession,
    updateWatchTime,
    resetSession,
  } = useSession();

  const [showCountdown, setShowCountdown] = useState(false);
  const [countdownValue, setCountdownValue] = useState(COUNTDOWN_SECONDS);
  const [showFeedback, setShowFeedback] = useState(false);
  const [sessionComplete, setSessionComplete] = useState(false);
  const [showTimeWarning, setShowTimeWarning] = useState(false);
  const [timeLimitReached, setTimeLimitReached] = useState(false);
  const countdownTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const sessionStartTimeRef = useRef(Date.now());
  const videoStartTimeRef = useRef(Date.now());
  const hardEndTriggered = useRef(false);

  const { isCasting, loadMedia } = useCast();
  const currentVideo = session.playlist[session.currentIndex];
  const isLastVideo = session.currentIndex >= session.playlist.length - 1;
  const nextVideo = !isLastVideo ? session.playlist[session.currentIndex + 1] : null;
  const canAppendWindDown = session.includeWindDown && session.calmingVideos.length > 0;

  const handleSessionEnd = useCallback(async () => {
    setSessionComplete(true);
    await endSession();
    setShowFeedback(true);
  }, [endSession]);

  useEffect(() => {
    if (!session.isActive && !sessionComplete) {
      router.replace('/(main)/children');
    }
  }, [session.isActive, sessionComplete, router]);

  useEffect(() => {
    videoStartTimeRef.current = Date.now();
  }, [session.currentIndex]);

  useEffect(() => {
    const sessionLimitSeconds = session.sessionMinutes * 60;
    const interval = setInterval(() => {
      const elapsed = Math.round((Date.now() - sessionStartTimeRef.current) / 1000);
      updateWatchTime(elapsed);

      if (elapsed >= sessionLimitSeconds && session.isActive && !hardEndTriggered.current) {
        if (session.finishMode === 'hard') {
          hardEndTriggered.current = true;
          clearInterval(interval);
          handleSessionEnd();
        } else {
          setTimeLimitReached(true);
          setShowTimeWarning(true);
        }
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [updateWatchTime, session.sessionMinutes, session.finishMode, session.isActive, handleSessionEnd]);

  useEffect(() => {
    if (isCasting && currentVideo) {
      loadMedia(currentVideo.youtubeId, currentVideo.title);
    }
  }, [isCasting, currentVideo?.youtubeId, loadMedia]);

  useEffect(() => {
    return () => {
      if (countdownTimer.current) {
        clearInterval(countdownTimer.current);
      }
    };
  }, []);

  const recordWatchHistory = useCallback(
    async (videoId: string, durationSeconds: number) => {
      if (!session.sessionId) return;
      try {
        await apiRequest('POST', '/api/watch-history', {
          sessionId: session.sessionId,
          videoId,
          childIds: session.childIds,
          durationSeconds: Math.round(durationSeconds),
          stimulationLevel: currentVideo?.stimulationLevel ?? 0,
        });
      } catch (err: unknown) {
        console.warn('Failed to record watch history:', err instanceof Error ? err.message : err);
      }
    },
    [session.sessionId, session.childIds, currentVideo],
  );

  const tryAdvanceOrEnd = useCallback(() => {
    if (timeLimitReached) {
      handleSessionEnd();
      return;
    }
    if (isLastVideo) {
      if (canAppendWindDown) {
        advanceVideo();
      } else {
        handleSessionEnd();
      }
    } else {
      advanceVideo();
    }
  }, [isLastVideo, canAppendWindDown, timeLimitReached, advanceVideo, handleSessionEnd]);

  const handleVideoEnd = useCallback(() => {
    if (currentVideo) {
      recordWatchHistory(currentVideo.id, currentVideo.durationSeconds);
    }

    if (timeLimitReached) {
      handleSessionEnd();
      return;
    }

    if (isLastVideo && !canAppendWindDown) {
      handleSessionEnd();
      return;
    }

    setShowCountdown(true);
    setCountdownValue(COUNTDOWN_SECONDS);
    countdownTimer.current = setInterval(() => {
      setCountdownValue(prev => {
        if (prev <= 1) {
          if (countdownTimer.current) clearInterval(countdownTimer.current);
          setShowCountdown(false);
          tryAdvanceOrEnd();
          return COUNTDOWN_SECONDS;
        }
        return prev - 1;
      });
    }, 1000);
  }, [currentVideo, isLastVideo, canAppendWindDown, timeLimitReached, tryAdvanceOrEnd, recordWatchHistory, handleSessionEnd]);

  const handleSkipCountdown = useCallback(() => {
    if (countdownTimer.current) {
      clearInterval(countdownTimer.current);
    }
    setShowCountdown(false);
    tryAdvanceOrEnd();
  }, [tryAdvanceOrEnd]);

  const handleSkipVideo = useCallback(() => {
    const videoElapsed = Math.round((Date.now() - videoStartTimeRef.current) / 1000);
    if (currentVideo) {
      recordWatchHistory(currentVideo.id, Math.min(videoElapsed, currentVideo.durationSeconds));
    }
    tryAdvanceOrEnd();
  }, [currentVideo, tryAdvanceOrEnd, recordWatchHistory]);

  const handleStopSession = useCallback(() => {
    Alert.alert(
      'End Session',
      'Are you sure you want to end this session?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Session',
          style: 'destructive',
          onPress: () => handleSessionEnd(),
        },
      ],
    );
  }, [handleSessionEnd]);

  const handleFeedbackDismiss = useCallback(() => {
    setShowFeedback(false);
    resetSession();
    router.replace('/(main)/children');
  }, [resetSession, router]);

  const handleProgress = useCallback(
    (_currentTime: number, _duration: number) => {},
    [],
  );

  if (!currentVideo) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No video available</Text>
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => router.replace('/(main)/children')}
          >
            <Text style={styles.backBtnText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <View style={styles.container}>
      <VideoPlayer
        youtubeId={currentVideo.youtubeId}
        onEnd={handleVideoEnd}
        onProgress={handleProgress}
        autoPlay={true}
      />

      {showCountdown && (
        <View style={styles.countdownOverlay}>
          <Text style={styles.countdownLabel}>Next video in</Text>
          <Text style={styles.countdownNumber}>{countdownValue}</Text>
          {nextVideo && (
            <Text style={styles.countdownTitle} numberOfLines={2}>
              {nextVideo.title}
            </Text>
          )}
          <TouchableOpacity
            style={styles.countdownBtn}
            onPress={handleSkipCountdown}
            testID="button-skip-countdown"
          >
            <Text style={styles.countdownBtnText}>Play Now</Text>
          </TouchableOpacity>
        </View>
      )}

      {showTimeWarning && (
        <View style={styles.timeWarning}>
          <Text style={styles.timeWarningText}>
            Session time is up. The current video will finish, then the session ends.
          </Text>
        </View>
      )}

      <SafeAreaView style={styles.controlsArea} edges={['bottom']}>
        <View style={styles.nowPlaying}>
          <View style={styles.nowPlayingInfo}>
            <Text style={styles.nowPlayingTitle} numberOfLines={2}>
              {currentVideo.title}
            </Text>
            <View style={styles.nowPlayingMeta}>
              <Text style={styles.nowPlayingDuration}>
                {formatDuration(currentVideo.durationSeconds)}
              </Text>
              <StimDots level={currentVideo.stimulationLevel} />
              <Text style={styles.nowPlayingPosition}>
                {session.currentIndex + 1} / {session.playlist.length}
              </Text>
            </View>
            {currentVideo.seriesName && (
              <Text style={styles.nowPlayingSeries}>{currentVideo.seriesName}</Text>
            )}
          </View>
        </View>

        <View style={styles.controlButtons}>
          <TouchableOpacity
            style={styles.controlBtn}
            onPress={handleSkipVideo}
            testID="button-skip"
          >
            <Text style={styles.controlBtnText}>
              {isLastVideo ? 'End Session' : 'Skip'}
            </Text>
          </TouchableOpacity>

          <CastButton style={styles.castBtn} />

          <TouchableOpacity
            style={[styles.controlBtn, styles.stopBtn]}
            onPress={handleStopSession}
            testID="button-stop-session"
          >
            <Text style={[styles.controlBtnText, styles.stopBtnText]}>Stop</Text>
          </TouchableOpacity>
        </View>

        {session.playlist.length > 1 && (
          <View style={styles.progressBar}>
            {session.playlist.map((_, i) => (
              <View
                key={i}
                style={[
                  styles.progressDot,
                  i < session.currentIndex && styles.progressDotComplete,
                  i === session.currentIndex && styles.progressDotCurrent,
                ]}
              />
            ))}
          </View>
        )}
      </SafeAreaView>

      <SessionFeedback
        visible={showFeedback}
        onDismiss={handleFeedbackDismiss}
        childIds={session.childIds}
        childNames={session.childNames}
        sessionId={session.sessionId || ''}
        totalMinutesWatched={Math.round(session.totalSecondsWatched / 60)}
        wasOverride={session.wasOverride}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.black,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing.md,
  },
  emptyText: {
    color: colors.white,
    fontSize: 18,
  },
  backBtn: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
  },
  backBtnText: {
    color: colors.white,
    fontWeight: '600',
  },
  countdownOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  countdownLabel: {
    color: '#94a3b8',
    fontSize: 16,
  },
  countdownNumber: {
    color: colors.white,
    fontSize: 72,
    fontWeight: '700',
    marginVertical: spacing.sm,
  },
  countdownTitle: {
    color: colors.white,
    fontSize: 16,
    textAlign: 'center',
    paddingHorizontal: spacing.xxl,
    marginBottom: spacing.lg,
  },
  countdownBtn: {
    backgroundColor: colors.primary,
    paddingHorizontal: spacing.xl,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.md,
  },
  countdownBtnText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  controlsArea: {
    flex: 1,
    backgroundColor: '#111',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  nowPlaying: {
    flex: 1,
  },
  nowPlayingInfo: {
    gap: spacing.xs,
  },
  nowPlayingTitle: {
    color: colors.white,
    fontSize: 18,
    fontWeight: '600',
    lineHeight: 24,
  },
  nowPlayingMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  nowPlayingDuration: {
    color: '#94a3b8',
    fontSize: 14,
  },
  nowPlayingPosition: {
    color: '#64748b',
    fontSize: 13,
  },
  nowPlayingSeries: {
    color: '#64748b',
    fontSize: 13,
  },
  stimDots: {
    flexDirection: 'row',
    gap: 3,
  },
  stimDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
  },
  controlButtons: {
    flexDirection: 'row',
    gap: spacing.md,
    marginBottom: spacing.md,
  },
  controlBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: borderRadius.md,
    backgroundColor: '#1e293b',
    alignItems: 'center',
  },
  controlBtnText: {
    color: colors.white,
    fontSize: 16,
    fontWeight: '600',
  },
  timeWarning: {
    backgroundColor: '#f59e0b20',
    borderBottomWidth: 1,
    borderBottomColor: '#f59e0b',
    paddingVertical: 8,
    paddingHorizontal: spacing.lg,
  },
  timeWarningText: {
    color: '#f59e0b',
    fontSize: 13,
    textAlign: 'center',
  },
  castBtn: {
    minWidth: 60,
  },
  stopBtn: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: colors.error,
  },
  stopBtnText: {
    color: colors.error,
  },
  progressBar: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 4,
    paddingBottom: spacing.md,
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#334155',
  },
  progressDotComplete: {
    backgroundColor: colors.primary,
  },
  progressDotCurrent: {
    backgroundColor: colors.white,
    width: 20,
    borderRadius: 4,
  },
});
