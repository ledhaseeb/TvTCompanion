import { useState, useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import Slider from '@react-native-community/slider';
import { colors, spacing, borderRadius } from '@/lib/theme';
import type { Child, TaperMode } from '@/lib/types';
import { TAPER_MODES } from '@/lib/types';

export default function SessionConfigScreen() {
  const { childIds: childIdsStr, childNames: childNamesStr } = useLocalSearchParams<{
    childIds: string;
    childNames: string;
  }>();
  const router = useRouter();

  const childIds = childIdsStr?.split(',') ?? [];
  const childNames = childNamesStr?.split(',') ?? [];

  const { data: children = [] } = useQuery<Child[]>({
    queryKey: ['/api/children'],
  });

  const selectedChildren = useMemo(
    () => children.filter(c => childIds.includes(c.id)),
    [children, childIds],
  );

  const defaultMinutes = useMemo(() => {
    if (selectedChildren.length === 0) return 30;
    return Math.min(...selectedChildren.map(c => c.entertainmentMinutes));
  }, [selectedChildren]);

  const [sessionMinutes, setSessionMinutes] = useState(defaultMinutes);
  const [taperMode, setTaperMode] = useState<TaperMode>('taper_down');
  const [flatlineLevel, setFlatlineLevel] = useState(3);
  const [includeWindDown, setIncludeWindDown] = useState(true);
  const [finishMode, setFinishMode] = useState<'soft' | 'hard'>('soft');

  const handleContinue = () => {
    router.push({
      pathname: '/(main)/playlist-preview',
      params: {
        childIds: childIds.join(','),
        childNames: childNames.join(','),
        sessionMinutes: String(sessionMinutes),
        taperMode,
        flatlineLevel: String(flatlineLevel),
        includeWindDown: includeWindDown ? '1' : '0',
        finishMode,
      },
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} testID="button-back">
          <Text style={styles.backText}>Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Session Setup</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Watching: {childNames.join(', ')}
          </Text>
          {childIds.length > 1 && (
            <Text style={styles.sectionSubtitle}>Group session</Text>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Session Length</Text>
          <Text style={styles.valueText}>{sessionMinutes} minutes</Text>
          <Slider
            style={styles.slider}
            minimumValue={10}
            maximumValue={120}
            step={5}
            value={sessionMinutes}
            onValueChange={setSessionMinutes}
            minimumTrackTintColor={colors.primary}
            maximumTrackTintColor={colors.border}
            thumbTintColor={colors.primary}
            testID="slider-session-length"
          />
          <View style={styles.sliderLabels}>
            <Text style={styles.sliderLabel}>10m</Text>
            <Text style={styles.sliderLabel}>120m</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Energy Pattern</Text>
          <Text style={styles.sectionSubtitle}>
            How should stimulation change during the session?
          </Text>
          <View style={styles.taperGrid}>
            {TAPER_MODES.map(mode => (
              <TouchableOpacity
                key={mode.value}
                style={[
                  styles.taperCard,
                  taperMode === mode.value && styles.taperCardSelected,
                ]}
                onPress={() => setTaperMode(mode.value)}
                testID={`button-taper-${mode.value}`}
              >
                <Text
                  style={[
                    styles.taperLabel,
                    taperMode === mode.value && styles.taperLabelSelected,
                  ]}
                >
                  {mode.label}
                </Text>
                <Text style={styles.taperDesc}>{mode.description}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {taperMode === 'flatline' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Steady Level</Text>
            <Text style={styles.valueText}>Level {flatlineLevel}</Text>
            <Slider
              style={styles.slider}
              minimumValue={1}
              maximumValue={5}
              step={1}
              value={flatlineLevel}
              onValueChange={setFlatlineLevel}
              minimumTrackTintColor={colors.stimulation[flatlineLevel]}
              maximumTrackTintColor={colors.border}
              thumbTintColor={colors.stimulation[flatlineLevel]}
              testID="slider-flatline-level"
            />
          </View>
        )}

        <View style={styles.section}>
          <View style={styles.switchRow}>
            <View style={styles.switchLabel}>
              <Text style={styles.switchTitle}>Wind-Down Video</Text>
              <Text style={styles.switchDesc}>
                Play a calming video after the session ends
              </Text>
            </View>
            <Switch
              value={includeWindDown}
              onValueChange={setIncludeWindDown}
              trackColor={{ false: colors.border, true: colors.primaryLight }}
              thumbColor={includeWindDown ? colors.primary : colors.textTertiary}
              testID="switch-wind-down"
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Finish Mode</Text>
          <View style={styles.finishRow}>
            <TouchableOpacity
              style={[
                styles.finishOption,
                finishMode === 'soft' && styles.finishOptionSelected,
              ]}
              onPress={() => setFinishMode('soft')}
              testID="button-finish-soft"
            >
              <Text
                style={[
                  styles.finishLabel,
                  finishMode === 'soft' && styles.finishLabelSelected,
                ]}
              >
                Soft
              </Text>
              <Text style={styles.finishDesc}>Finish current video</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.finishOption,
                finishMode === 'hard' && styles.finishOptionSelected,
              ]}
              onPress={() => setFinishMode('hard')}
              testID="button-finish-hard"
            >
              <Text
                style={[
                  styles.finishLabel,
                  finishMode === 'hard' && styles.finishLabelSelected,
                ]}
              >
                Hard
              </Text>
              <Text style={styles.finishDesc}>Stop immediately</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.continueButton}
          onPress={handleContinue}
          testID="button-continue-to-preview"
        >
          <Text style={styles.continueButtonText}>Preview Playlist</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  backText: {
    color: colors.primary,
    fontSize: 16,
    fontWeight: '500',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: colors.text,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: spacing.lg,
    paddingBottom: 120,
  },
  section: {
    marginBottom: spacing.xl,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: colors.text,
    marginBottom: spacing.xs,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: colors.textSecondary,
    marginBottom: spacing.sm,
  },
  valueText: {
    fontSize: 28,
    fontWeight: '700',
    color: colors.primary,
    textAlign: 'center',
    marginVertical: spacing.sm,
  },
  slider: {
    width: '100%',
    height: 40,
  },
  sliderLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xs,
  },
  sliderLabel: {
    fontSize: 12,
    color: colors.textTertiary,
  },
  taperGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  taperCard: {
    width: '48%',
    padding: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 2,
    borderColor: colors.border,
    backgroundColor: colors.surface,
  },
  taperCardSelected: {
    borderColor: colors.primary,
    backgroundColor: '#e8f0fe',
  },
  taperLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: colors.text,
  },
  taperLabelSelected: {
    color: colors.primary,
  },
  taperDesc: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  switchLabel: {
    flex: 1,
    marginRight: spacing.md,
  },
  switchTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
  },
  switchDesc: {
    fontSize: 13,
    color: colors.textSecondary,
    marginTop: 2,
  },
  finishRow: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
  finishOption: {
    flex: 1,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 2,
    borderColor: colors.border,
    alignItems: 'center',
  },
  finishOptionSelected: {
    borderColor: colors.primary,
    backgroundColor: '#e8f0fe',
  },
  finishLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.text,
  },
  finishLabelSelected: {
    color: colors.primary,
  },
  finishDesc: {
    fontSize: 12,
    color: colors.textSecondary,
    marginTop: 2,
  },
  footer: {
    padding: spacing.lg,
    paddingBottom: spacing.xxl,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    backgroundColor: colors.background,
  },
  continueButton: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: 16,
    alignItems: 'center',
  },
  continueButtonText: {
    color: colors.white,
    fontSize: 17,
    fontWeight: '600',
  },
});
