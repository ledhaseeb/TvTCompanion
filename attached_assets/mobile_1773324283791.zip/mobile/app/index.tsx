import { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useAuth } from '@/contexts/AuthContext';
import { signInWithEmail, signUpWithEmail, signInWithGoogleToken } from '@/lib/auth';
import { colors, spacing, borderRadius } from '@/lib/theme';

export default function LoginScreen() {
  const { user, isLoading, login } = useAuth();
  const router = useRouter();
  const params = useLocalSearchParams<{ redirect?: string; token?: string }>();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!isLoading && user) {
      if (params.redirect === 'invite' && params.token) {
        router.replace(`/invite?token=${params.token}`);
      } else {
        router.replace('/(main)/children');
      }
    }
  }, [isLoading, user, router, params.redirect, params.token]);

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  if (user) {
    return null;
  }

  const handleGoogleSignIn = async () => {
    setSubmitting(true);
    setError(null);
    try {
      let googleSignInModule: {
        configure: (opts: { webClientId?: string }) => void;
        hasPlayServices: () => Promise<void>;
        signIn: () => Promise<{ idToken?: string | null }>;
      };
      try {
        const mod = require('@react-native-google-signin/google-signin');
        googleSignInModule = mod.GoogleSignin;
      } catch {
        setError('Google Sign-In requires a native build (not available in Expo Go)');
        setSubmitting(false);
        return;
      }

      googleSignInModule.configure({
        webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
      });

      await googleSignInModule.hasPlayServices();
      const userInfo = await googleSignInModule.signIn();
      const googleIdToken = userInfo.idToken;

      if (!googleIdToken) {
        throw new Error('No ID token received from Google');
      }

      const firebaseToken = await signInWithGoogleToken(googleIdToken);
      await login(firebaseToken);
    } catch (err: unknown) {
      const error = err as { code?: string; message?: string };
      if (error.code !== 'SIGN_IN_CANCELLED') {
        setError(error.message || 'Google sign-in failed');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleEmailAuth = async () => {
    if (!email.trim() || !password.trim()) {
      setError('Please enter both email and password');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      let idToken: string;
      if (isSignUp) {
        idToken = await signUpWithEmail(email.trim(), password);
      } else {
        idToken = await signInWithEmail(email.trim(), password);
      }
      await login(idToken);
    } catch (err: unknown) {
      const firebaseErr = err as { code?: string; message?: string };
      const code = firebaseErr.code;
      if (code === 'auth/user-not-found' || code === 'auth/wrong-password' || code === 'auth/invalid-credential') {
        setError('Invalid email or password');
      } else if (code === 'auth/email-already-in-use') {
        setError('An account with this email already exists');
      } else if (code === 'auth/weak-password') {
        setError('Password must be at least 6 characters');
      } else if (code === 'auth/invalid-email') {
        setError('Please enter a valid email address');
      } else {
        setError(firebaseErr.message || 'Authentication failed');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.header}>
          <Text style={styles.logo}>SafeWatch</Text>
          <Text style={styles.subtitle}>Child-safe viewing, anywhere</Text>
        </View>

        <View style={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor={colors.textTertiary}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            testID="input-email"
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor={colors.textTertiary}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            testID="input-password"
          />

          {error && <Text style={styles.errorText}>{error}</Text>}

          <TouchableOpacity
            style={[styles.button, submitting && styles.buttonDisabled]}
            onPress={handleEmailAuth}
            disabled={submitting}
            testID="button-login"
          >
            {submitting ? (
              <ActivityIndicator color={colors.white} />
            ) : (
              <Text style={styles.buttonText}>
                {isSignUp ? 'Create Account' : 'Sign In'}
              </Text>
            )}
          </TouchableOpacity>

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </View>

          <TouchableOpacity
            style={[styles.googleButton, submitting && styles.buttonDisabled]}
            onPress={handleGoogleSignIn}
            disabled={submitting}
            testID="button-google-signin"
          >
            <Text style={styles.googleButtonText}>Sign in with Google</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              setIsSignUp(!isSignUp);
              setError(null);
            }}
            testID="button-toggle-auth-mode"
          >
            <Text style={styles.switchText}>
              {isSignUp
                ? 'Already have an account? Sign in'
                : "Don't have an account? Sign up"}
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.footerText}>
          Sign in with your SafeWatch account to start a viewing session
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: spacing.lg,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.background,
  },
  loadingText: {
    marginTop: spacing.md,
    color: colors.textSecondary,
    fontSize: 16,
  },
  header: {
    alignItems: 'center',
    marginBottom: spacing.xxl,
  },
  logo: {
    fontSize: 36,
    fontWeight: '700',
    color: colors.primary,
    letterSpacing: -1,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
  form: {
    gap: spacing.md,
  },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    paddingHorizontal: spacing.md,
    paddingVertical: 14,
    fontSize: 16,
    color: colors.text,
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: borderRadius.md,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: colors.white,
    fontSize: 17,
    fontWeight: '600',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: spacing.sm,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: colors.border,
  },
  dividerText: {
    paddingHorizontal: spacing.md,
    color: colors.textTertiary,
    fontSize: 13,
  },
  googleButton: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: borderRadius.md,
    paddingVertical: 16,
    alignItems: 'center',
  },
  googleButtonText: {
    color: colors.text,
    fontSize: 17,
    fontWeight: '600',
  },
  switchText: {
    textAlign: 'center',
    color: colors.primary,
    fontSize: 14,
    marginTop: spacing.sm,
  },
  errorText: {
    color: colors.error,
    fontSize: 14,
    textAlign: 'center',
  },
  footerText: {
    textAlign: 'center',
    color: colors.textTertiary,
    fontSize: 13,
    marginTop: spacing.xxl,
  },
});
